UPLOAD KE GITHUB:
1. Ekstrak ZIP ini.
2. Di repo Digital-Safety-Walk-Checklist, upload file index.html ke folder paling luar (root).
3. Jika ada index.htm lama, hapus agar tidak membingungkan.
4. Commit changes.
5. GitHub Pages: Settings > Pages > Deploy from branch > main > /(root).
6. Tunggu beberapa menit lalu buka URL Pages.
Catatan: foto hero mengambil foto Wikimedia Commons dan membutuhkan internet. Logo PBTR sudah tertanam di index.html.
